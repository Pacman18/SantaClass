using UnityEngine;
using Unity.Entities;

namespace Santa
{
    // 최상위 Agent Entity
    public class AgentEntity : MonoBehaviour
    {

        private Entity _entity;

        protected Entity entity => _entity;

        private EntityManager _entityManager;
        protected EntityManager entityManager => _entityManager;

        protected virtual void Awake()
        {
            var world = World.DefaultGameObjectInjectionWorld;
            _entityManager = world.EntityManager;
            _entity = _entityManager.CreateEntity(typeof(Agent));       

        }

        protected virtual void OnEnable()
        {
            _entityManager.SetEnabled(_entity, true);
        }

        protected virtual void OnDisable()
        {
            if(World.DefaultGameObjectInjectionWorld == null)
                return;
            
            _entityManager.SetEnabled(_entity, false);
        }

        protected virtual void OnDestroy()
        {
            if(World.DefaultGameObjectInjectionWorld == null)
                return;

            _entityManager.DestroyEntity(_entity);
            _entity = Entity.Null;
        }    
    }

    public struct Agent : IComponentData { }

    public struct InitializeTag : IComponentData , IEnableableComponent  { }

}
