using UnityEngine;
using Unity.Entities;

namespace Santa
{
    public class ResourceContainerAuthoring : MonoBehaviour
    {
        public GameObject CharacterPrefab;


        public  class ResourceContainBaker : Baker<ResourceContainerAuthoring>
        {
            public override void Bake(ResourceContainerAuthoring authoring)
            {
                var entity = GetEntity(authoring, TransformUsageFlags.Dynamic);
                AddComponent(entity, new ResourceContainer{Character = GetEntity(authoring.CharacterPrefab, TransformUsageFlags.Dynamic)});
            }

        }
    }


    public struct ResourceContainer : IComponentData
    {
        public Entity Character;
    }

}
