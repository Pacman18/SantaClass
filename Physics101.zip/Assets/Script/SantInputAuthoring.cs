using UnityEngine;
using Unity.Entities;
using Unity.Physics;
using Unity.Physics.Systems;
using Unity.VisualScripting;

namespace Santa
{
    public class SantInputAuthoring : AgentEntity
    {

        private SystemHandle _buildHandle;
        private SystemHandle _stepHandle;
        private SystemHandle _exportHandle;

        protected override void Awake()
        {
            base.Awake();            
            entityManager.AddComponentData(entity, new SantInputData());
        }


        private void Update()
        {
            if(Input.GetMouseButtonDown(0))
            {
                var input = new SantInputData();    
                input.MouseButton_0_Presssd = true;
                entityManager.SetComponentData(entity, input);
            }

            if(Input.GetMouseButtonDown(1))
            {
                var input = new SantInputData();    
                input.MouseButton_1_Presssd = true;
                entityManager.SetComponentData(entity, input);
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                Debug.Log("수동으로 FixedStep Group 실행");

   
            }
        }
    }


    public struct SantInputData : IComponentData
    {
        public bool MouseButton_0_Presssd;
        public bool MouseButton_1_Presssd;

        public bool LeftPressed;
        public bool RightPressed;
        public bool UpPressed;
        public bool DownPressed;
        public bool JumpPressed;
        public bool AttackPressed;
        public bool SpecialPressed;

        public void Reset()
        {
            MouseButton_0_Presssd = false;
            MouseButton_1_Presssd = false;
            LeftPressed = false;
            RightPressed = false;
            UpPressed = false;
            DownPressed = false;
            JumpPressed = false;
            AttackPressed = false;
            SpecialPressed = false;            
        }
    }
}
