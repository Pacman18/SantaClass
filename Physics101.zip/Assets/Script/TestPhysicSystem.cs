using ActivationPlates;
using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;


namespace Santa
{

    // Fixed로 돌게됨 
    [UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]
    public partial struct TestPhysicSystem : ISystem
    {

        //[BurstCompile]
        public void OnCreate(ref SystemState state)
        {
            state.RequireForUpdate<SantInputData>();
            
            var entity = state.EntityManager.CreateEntity(typeof(TestPhysicData));
            state.EntityManager.SetComponentData(entity, new TestPhysicData{
                AccCount = 0,
                InterverTime = 10,
                OverCount = 20,
            });

        }

        [BurstCompile]
        public void OnUpdate(ref SystemState state)
        {
            var input = SystemAPI.GetSingleton<SantInputData>();            
            if(input.FixedStep == false)
            {
                return;           
            }

            input.FixedStep = false;

            bool isSpawn = false;
            bool stop = false;
            foreach(var entity in SystemAPI.Query<RefRW<TestPhysicData>>())
            {
                entity.ValueRW.AccCount++;
                if(entity.ValueRW.AccCount >= entity.ValueRW.InterverTime)
                {
                    isSpawn = true;
                    entity.ValueRW.AccCount = 0;
                    entity.ValueRW.OverCount--;
                    if(entity.ValueRW.OverCount <= 0)
                    {
                        stop = true;
                    }
                }
            }           

            if(isSpawn)
            {
                var config = SystemAPI.GetSingleton<Config>();                
                state.EntityManager.Instantiate(config.SpawnPrefab);
            }

            if(stop)
                state.Enabled = false;
        }

        [BurstCompile]
        public void OnDestroy(ref SystemState state)
        {
            
        }
    }


    public struct TestPhysicData : IComponentData
    {
        public int AccCount;
        public int InterverTime;

        public int OverCount;

    }


}
