using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;

namespace Santa
{
    public struct AgentMoveDirection : IComponentData
    {
        public float2 Value;
    }

    public struct AgentMoveSpeed : IComponentData
    {
        public float Value;
    }

    public class AgentAuthoring : MonoBehaviour
    {
        public float moveSpeed = 10;
        public Vector3 moveDirection = new Vector3(0, 0, 1);

        private class Baker : Baker<AgentAuthoring>
        {
            public override void Bake(AgentAuthoring authoring)
            {
                var entity = GetEntity(authoring, TransformUsageFlags.Dynamic);

                //AddComponent<PlayerMoveDirection>(entity); 
                AddComponent(entity, new AgentMoveDirection { Value = new float2(authoring.moveDirection.x, authoring.moveDirection.z) });
                AddComponent(entity, new AgentMoveSpeed { Value = authoring.moveSpeed });

            }
        }
    
    }

}

