using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms; 
using Santa;
using Unity.Burst;
using Unity.Physics;
public partial struct AgentSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<AgentMoveDirection>();
        state.RequireForUpdate<AgentMoveSpeed>();
    }


    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        /*var deltaTime = SystemAPI.Time.DeltaTime;

        foreach( var (velocity, moveDirection, moveSpeed) in SystemAPI.Query<RefRW<PhysicsVelocity> , AgentMoveDirection, AgentMoveSpeed>())
        {
            velocity.ValueRW.Linear = new float3(moveDirection.Value.x, 0, moveDirection.Value.y) * moveSpeed.Value;
        }*/
    }
}
