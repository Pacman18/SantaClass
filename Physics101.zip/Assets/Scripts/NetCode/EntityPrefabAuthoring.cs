using UnityEngine;
using Unity.Entities;
using Unity.NetCode;

public class EntityPrefabAuthoring : MonoBehaviour
{
    public GameObject PlayerPrefab;


    public class Baker : Baker<EntityPrefabAuthoring>
    {
        public override void Bake(EntityPrefabAuthoring authoring)
        {
            Entity entity = GetEntity(TransformUsageFlags.Dynamic);
            Entity prefabEntity = GetEntity(authoring.PlayerPrefab, TransformUsageFlags.Dynamic);

            AddComponent( entity, new EntityPrefabReference{ Value = prefabEntity});
        }
    }   
    
}


public struct EntityPrefabReference : IComponentData
{
    public Entity Value;
    //public InputEvent
}
