using UnityEngine;
using Unity.NetCode;

[UnityEngine.Scripting.Preserve]
public class GameBootStrap : ClientServerBootstrap
{
    public override bool Initialize(string defaultWorldName)
    {
        AutoConnectPort = 4885;
        return base.Initialize(defaultWorldName);   

    }
}