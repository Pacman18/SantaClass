using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.NetCode;
using Unity.Transforms;
using UnityEngine;

[WorldSystemFilter(WorldSystemFilterFlags.ServerSimulation)]
partial struct GoGameInServerSystem : ISystem
{
    [BurstCompile]
    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<EntityPrefabReference>();
        state.RequireForUpdate<NetworkId>();
    }

    //[BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        EntityCommandBuffer ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);

        var entityPrefabReference = SystemAPI.GetSingleton<EntityPrefabReference>();

        foreach(var (goInGameRequest, entity) in SystemAPI.Query<RefRO<ReceiveRpcCommandRequest>>().WithAll<GoInGameRequestRPC>().WithEntityAccess())
        {
            ecb.AddComponent<NetworkStreamInGame>(goInGameRequest.ValueRO.SourceConnection);
            ecb.DestroyEntity(entity);

            Debug.Log("Go Game In Server : " + goInGameRequest.ValueRO.SourceConnection);

            var player = ecb.Instantiate(entityPrefabReference.Value);

            ecb.SetComponent(player, LocalTransform.FromPosition(new float3(0, 1, 0)));

            var networkId = SystemAPI.GetComponent<NetworkId>(goInGameRequest.ValueRO.SourceConnection);

            ecb.AddComponent(player, new GhostOwner{ NetworkId = networkId.Value});     

            ecb.AppendToBuffer(goInGameRequest.ValueRO.SourceConnection , new LinkedEntityGroup{  Value = player});       
        }

        ecb.Playback(state.EntityManager);
        
    }

    [BurstCompile]
    public void OnDestroy(ref SystemState state)
    {
        
    }
}
