using Unity.Entities;
using UnityEngine;
using Unity.NetCode; 
using Unity.Burst;
using Unity.Transforms;
using Unity.Mathematics;


[UpdateInGroup(typeof(PredictedSimulationSystemGroup))]
partial struct NetcodePlayerMovementSystem : ISystem
{
    /*[BurstCompile]
    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<NetworkStreamInGame>();
        state.RequireForUpdate<NetcodePlayerInput>();

    }*/

    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        foreach(var (netcodePlayerInput, localTransform) in SystemAPI.Query<RefRW<NetcodePlayerInput>, RefRW<LocalTransform>>().WithAll<Simulate>())
        {
            var moveDirection = netcodePlayerInput.ValueRO.Value;

            var direction = new float3(moveDirection.x, 0, moveDirection.y);
            localTransform.ValueRW.Position += direction * SystemAPI.Time.DeltaTime * 10;
        }
    }
}
