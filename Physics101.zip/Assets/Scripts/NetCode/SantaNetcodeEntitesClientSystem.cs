using Unity.Burst;
using Unity.Entities;
using Unity.NetCode;
using UnityEngine;


// 클라이언트만 돌아갈때 플레그
[WorldSystemFilter(WorldSystemFilterFlags.ClientSimulation)]
partial struct SantaNetcodeEntitesClientSystem : ISystem
{
    [BurstCompile]
    public void OnCreate(ref SystemState state)
    {
        
    }

    //[BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
         if(Input.GetKeyDown(KeyCode.Space))
        {
            // Send RPC 
            Entity rpcEntity = state.EntityManager.CreateEntity();
            
            state.EntityManager.AddComponentData(rpcEntity, new SimpleRPC{ value = 488});
            state.EntityManager.AddComponentData(rpcEntity, new SendRpcCommandRequest());

            Debug.Log("RPC Sent");
        }
    }

    [BurstCompile]
    public void OnDestroy(ref SystemState state)
    {
        
    }
}
