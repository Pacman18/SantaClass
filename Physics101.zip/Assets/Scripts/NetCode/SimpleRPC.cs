using Unity.NetCode;
using UnityEngine;

public struct SimpleRPC : IRpcCommand
{
    public int value;
    
}
