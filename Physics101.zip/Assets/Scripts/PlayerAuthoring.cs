using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;



namespace Santa 
{

    public struct PlayerTag : IComponentData {}

    public class PlayerAuthoring : MonoBehaviour
    {


        private class Baker : Baker<PlayerAuthoring>
        {
            public override void Bake(PlayerAuthoring authoring)
            {
                var entity = GetEntity(authoring, TransformUsageFlags.Dynamic);
                AddComponent(entity, new PlayerTag());

            }
        }
        
    }
}
