using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;



namespace Santa
{
    // netcode 테스트로 잠시 주석처리 
    public partial class PlayerInputSystem : SystemBase
    {
        public DotInputAction _input;

        protected override void OnCreate()
        {
            _input = new DotInputAction();
            _input.Enable();
        }

        protected override void OnUpdate()
        {

            /*var currentInput = (float2)_input.Player.Move.ReadValue<Vector2>();

            foreach(var (moveDirection,  playerTag) in SystemAPI.Query<RefRW<AgentMoveDirection>, PlayerTag>())
            {
                moveDirection.ValueRW.Value = currentInput;                
            }*/            
        }
    }
}


